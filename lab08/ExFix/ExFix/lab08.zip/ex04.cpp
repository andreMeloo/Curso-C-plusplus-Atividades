#include <iostream>
#include <Windows.h>
#include <cmath>

using namespace std;



int main()
{
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);

	cout << "considerando o float - letra a, letra b, letra c, letra d, letra e"
}