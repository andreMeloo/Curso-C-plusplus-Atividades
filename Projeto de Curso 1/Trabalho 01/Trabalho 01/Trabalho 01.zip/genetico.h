#pragma once
#include <iostream>
#include <Windows.h>

bool funcaoDeAvaliacao(unsigned short);
unsigned short cruzamentoPontoUnico(unsigned short, unsigned short);
unsigned short cruzamentoAritmetico(unsigned short,  unsigned short);
unsigned short mutacaoSimples(unsigned short);
unsigned short mutacaoDupla(unsigned short);
