#define CRT_SECURE_NO_WARNINGS_
#include <iostream>
#include <Windows.h>
#include <cstring>
#include <cmath>

using namespace std;

int main()
{
	// N�o � um codigo v�lido, a instru��o 'delete' s� pode ser usada ap�s a utiliza��o/aloca��o de memoria manual utilizando a nota��o 'new;'
}