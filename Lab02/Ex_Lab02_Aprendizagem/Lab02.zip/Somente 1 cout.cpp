#include<Windows.h>
#include<iostream>

using namespace std;

int main()
{
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);

	cout << "C\n     +\n          +" << endl;

	system("Pause");
	return 0;
}