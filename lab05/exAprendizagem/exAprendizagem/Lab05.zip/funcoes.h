#pragma once

double modulo(double, double);
double retornaGraus(double, double);
