#include <iostream>
#include <Windows.h>
#include <cmath>

using namespace std;

int main() {
	

	cout << "a. ch != q && ch != k" << endl;
	cout << "b. idade <= 15 || idade >= 26" << endl;
	cout << "c. x % 2 != 0 && x > 30" << endl;
	cout << "d. num % 5 = 0 || num % 8 = 0" << endl;
	cout << "e. peso >= 50 && altura > 160" << endl;

}