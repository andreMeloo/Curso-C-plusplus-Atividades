#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <cstring>

using namespace std;

int main()
{
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);

	int A[] = { 46, 78, 40, 96, 74, 58, 32, 56, 91, 6 }, cont = 0;
	

}