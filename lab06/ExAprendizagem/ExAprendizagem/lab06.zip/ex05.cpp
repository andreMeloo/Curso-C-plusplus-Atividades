#include <iostream>
#include <Windows.h>
#include <climits>
using namespace std;

boolean isShort(long long);
boolean isInt(long long);

int main()
{
	SetConsoleCP(1252);
	SetConsoleOutputCP(1252);

	long long valor_inteiro;
	

	cout << "Digite um valor inteiro: ";
	cin >> valor_inteiro;

	if (isShort(valor_inteiro) == true)
	{
		cout << valor_inteiro << " cabe em 16 bits" << endl;
	}
	else
	{
		cout << valor_inteiro << " n�o cabe em 16 bits" << endl ; 
	}

	if (isInt(valor_inteiro) == true)
	{
		cout << valor_inteiro << " cabe em 32 bits" << endl;
	}
	else
	{
		cout << valor_inteiro << " n�o cabe em 32 bits" << endl;
	}

}

boolean isShort(long long valor_escolhido)
{
	int maximo = SHRT_MAX, minimo = SHRT_MIN;

	if (valor_escolhido < maximo && valor_escolhido > minimo)
	{
		return true;
	}
	else
	{
		return false;
	}

}

boolean isInt(long long valor_escolhido)
{
	int maximo = INT_MAX, minimo = INT_MIN;

	if (valor_escolhido < maximo && valor_escolhido > minimo)
	{
		return true;
	}
	else
	{
		return false;
	}

}
